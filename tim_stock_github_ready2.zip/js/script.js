const apiKey = "IDE2DA6MJ0MTNK70";
const symbols = ["AAPL","TSLA","MSFT","GOOGL","AMZN"];
const stockTableBody = document.querySelector("#stockTable tbody");
const newsList = document.getElementById("newsList");

async function fetchStock(symbol){
  const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`;
  try{
    const res = await fetch(url);
    const data = await res.json();
    const q = data["Global Quote"];
    return {
      symbol: symbol,
      price: q["05. price"],
      change: q["09. change"]
    };
  }catch(e){
    console.error("Error fetching", symbol, e);
    return {symbol, price:"-", change:"-"};
  }
}

async function updateStocks(){
  stockTableBody.innerHTML = "<tr><td colspan='3'>Loading...</td></tr>";
  const results = await Promise.all(symbols.map(fetchStock));
  stockTableBody.innerHTML = results.map(r => `
    <tr>
      <td>${r.symbol}</td>
      <td>$${parseFloat(r.price).toFixed(2)}</td>
      <td>${r.change}</td>
    </tr>`).join("");
}

// Dummy news (placeholder)
function loadNews(){
  newsList.innerHTML = `
    <li>Wall Street ends higher on tech gains</li>
    <li>Federal Reserve signals cautious outlook</li>
    <li>Tesla announces new model updates</li>
  `;
}

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Initial load
updateStocks();
loadNews();
// Refresh every 60s
setInterval(updateStocks, 60000);
